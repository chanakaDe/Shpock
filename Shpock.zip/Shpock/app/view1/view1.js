'use strict';

angular.module('myApp.view1', ['ngRoute'])

    .config(['$routeProvider', function ($routeProvider) {
        $routeProvider.when('/view1', {
            templateUrl: 'view1/view1.html',
            controller: 'View1Ctrl'
        });
    }])

    .controller('View1Ctrl', function ($scope) {

        $scope.filter = {
            timePeriod: '',
            sortValue: '',
            radius: '',
            my_country: '',
            category: '',
            new_in_your_area: '',
            everything: '',
            fashion_and_accessories: '',
            electronics: '',
            sports_leisure_games: '',
            car_and_motors: '',
            services: '',
            home_and_garden: '',
            baby_and_child: '',
            movies_books_music: '',
            property: '',
            other: '',
            min_price: '',
            max_price: ''
        };
        $scope.timePeriodOutPut = "7 days";
        $scope.filter.sortValue = "distance";
        $scope.radiusOutPut = "100 km";
        $scope.filter.category = "everything";
        $scope.selectedCategories = [];
        $scope.filter.everything = true;

        $scope.detectSearching = function () {
            $scope.showFilters = true;
            $scope.showFilterOutput = false;
        };

        $scope.getTimePeriodValue = function () {

            var timePeriod = $scope.filter.timePeriod;
            if (timePeriod > 80) {
                $scope.timePeriodOutPut = "FOREVER";
            } else if (timePeriod > 60) {
                $scope.timePeriodOutPut = "30 days";
            } else if (timePeriod > 40) {
                $scope.timePeriodOutPut = "7 days";
            } else if (timePeriod > 20) {
                $scope.timePeriodOutPut = "3 days";
            } else {
                $scope.timePeriodOutPut = "24 hours";
            }
        };

        $scope.getRadiusValue = function () {
            var radius = $scope.filter.radius;
            if (radius > 90) {
                $scope.radiusOutPut = "Everywhere";
            } else if (radius > 85) {
                $scope.radiusOutPut = "1000 km";
            } else if (radius > 80) {
                $scope.radiusOutPut = "500 km";
            } else if (radius > 75) {
                $scope.radiusOutPut = "400 km";
            } else if (radius > 65) {
                $scope.radiusOutPut = "300 km";
            } else if (radius > 55) {
                $scope.radiusOutPut = "200 km";
            } else if (radius > 45) {
                $scope.radiusOutPut = "100 km";
            } else if (radius > 35) {
                $scope.radiusOutPut = "30 km";
            } else if (radius > 25) {
                $scope.radiusOutPut = "20 km";
            } else if (radius > 15) {
                $scope.radiusOutPut = "10 km";
            } else if (radius > 12) {
                $scope.radiusOutPut = "5 km";
            } else if (radius > 10) {
                $scope.radiusOutPut = "4 km";
            } else if (radius > 8) {
                $scope.radiusOutPut = "3 km";
            } else if (radius > 5) {
                $scope.radiusOutPut = "2 km";
            } else if (radius > 1) {
                $scope.radiusOutPut = "1 km";
            }
        };

        $scope.submitForm = function () {

            if ($scope.filter.new_in_your_area) {
                $scope.selectedCategories.push("new_in_your_area");
            }
            if ($scope.filter.everything) {
                $scope.selectedCategories.push("everything");
            }
            if ($scope.filter.fashion_and_accessories) {
                $scope.selectedCategories.push("fashion_and_accessories");
            }
            if ($scope.filter.electronics) {
                $scope.selectedCategories.push("electronics");
            }
            if ($scope.filter.sports_leisure_games) {
                $scope.selectedCategories.push("sports_leisure_games");
            }
            if ($scope.filter.car_and_motors) {
                $scope.selectedCategories.push("car_and_motors");
            }
            if ($scope.filter.services) {
                $scope.selectedCategories.push("services");
            }
            if ($scope.filter.baby_and_child) {
                $scope.selectedCategories.push("baby_and_child");
            }
            if ($scope.filter.movies_books_music) {
                $scope.selectedCategories.push("movies_books_music");
            }
            if ($scope.filter.property) {
                $scope.selectedCategories.push("property");
            }
            if ($scope.filter.other) {
                $scope.selectedCategories.push("other");
            }

            var filter = {
                timePeriod: $scope.timePeriodOutPut,
                sortValue: $scope.filter.sortValue,
                radius: $scope.radiusOutPut,
                categories: $scope.selectedCategories
            };
            if ($scope.filter.my_country !== "") {
                filter.my_country = $scope.filter.my_country;
            }
            if ($scope.filter.min_price !== "") {
                filter.min_price = $scope.filter.min_price;
            }
            if ($scope.filter.max_price !== "") {
                filter.max_price = $scope.filter.max_price;
            }
            $scope.filterOutputData = filter;
            console.log(filter);
            $scope.showFilters = false;
            $scope.showFilterOutput = true;
            $scope.selectedCategories = [];
        };

    });